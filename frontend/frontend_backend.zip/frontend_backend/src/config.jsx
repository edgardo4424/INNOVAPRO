// src/config.js
export const APP_VERSION = "INNOVA-PRO+ v1.1.0"; 
